from django.db import models
from django.contrib.auth.models import AbstractUser, UserManager as AbstractUserManager
from django.conf import settings
from django.contrib.auth import get_user_model



class Members(models.Model):
    fname = models.CharField(max_length=200)
    lname = models.CharField(max_length=200)
    email = models.EmailField(max_length=200)
    password = models.CharField(max_length=200)

    def __str__(self):
        return self.fname + ' ' + self.lname
class UserManager(AbstractUserManager):
  pass

class User(AbstractUser):
    objects = UserManager()
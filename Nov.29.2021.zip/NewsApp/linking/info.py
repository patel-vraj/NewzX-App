EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'aatman.dave@gmail.com'
EMAIL_HOST_PASSWORD = 'Rutgers2022'
EMAIL_PORT = 587
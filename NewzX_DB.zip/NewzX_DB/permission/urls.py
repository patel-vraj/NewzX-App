from django.contrib import admin
from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^$', views.index, name="index"),
    url('signup', views.signup, name="signup"),
    url('signing', views.signing, name="login"),
    url('signout', views.signout, name="signout"),
    url('userPage', views.userPage, name='userPage'),
    url('contact', views.contact, name='contact'),
    url('about', views.about, name='about'),
    url('resetPassword', views.resetPassword, name='resetPassword'),
    url('profile', views.profile, name='profile')
]
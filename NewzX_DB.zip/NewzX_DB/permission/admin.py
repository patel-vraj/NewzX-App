from django.contrib import admin
from .models import Members, UserManager, User
# Register your models here.
admin.site.register(Members)
admin.site.register(User)
admin.site.register(UserManager)
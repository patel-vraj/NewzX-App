from django.db import models

class chkCategory(models.Model):
    categoryName=models.BooleanField(max_length=100)


class Article(models.Model):
    title = models.CharField(max_length=256)
    intro_image = models.ImageField(null=True, blank=True, upload_to=doc_hash)
    description = models.TextField(null=True, blank=True)

class Favorite(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)
    article = models.ForeignKey(Article, null=True,on_delete=models.CASCADE)
    class Meta:
        unique_together = ('user', 'article')

class EmailChangeAuth(models.Model):
    auth_key = models.CharField(max_length=42)
    user = models.ForeignKey(User)
    new_email = models.CharField(max_length=256)
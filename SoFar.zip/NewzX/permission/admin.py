from django.contrib import admin
from .models import chkCategory
# Register your models here.
admin.site.register(chkCategory)
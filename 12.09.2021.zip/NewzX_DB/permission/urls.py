from django.contrib import admin
from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^$', views.index, name="index"),
    url('signup', views.signup, name="signup"),
    url('signing', views.signing, name="login"),
    url('signout', views.signout, name="signout"),
    url('userPage', views.userPage, name='userPage'),
    url('Profile', views.Profile, name='Profile'),
    url('about', views.about, name='about'),
    url('contact', views.contact, name='contact'),
    url('news', views.news, name='news'),
    url('F_Password', views.F_Password, name='F_Password'),
]
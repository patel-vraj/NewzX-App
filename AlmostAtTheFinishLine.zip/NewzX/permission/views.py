from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages, admin
from django.contrib.auth import authenticate, login, logout
from linking import settings
from django.core.mail import send_mail
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_text
from . tokens import tokengenerated
from django.core.mail import EmailMessage, send_mail
from newsapi import NewsApiClient
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
import json

# Create your views here.

def signup(request):
    if request.method=="POST":
        lname = request.POST.get('lname')
        fname = request.POST.get('fname')
        username = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('pass1')
        pass2 = request.POST.get('pass2')
        if User.objects.filter(username=username):
            messages.error(request, "Username already exists! Please try another username!")
            return redirect('signup')
        if User.objects.filter(email=email):
            messages.error(request, "Email is already in use!")
            return redirect('signup')
        if len(username)<8:
            messages.error(request, "Username must be 8 characters minimum")
            return redirect('signup')
        if pass1 != pass2:
            messages.error(request, "Passwords do not match!")
            return redirect('signup')

        if not username.isalnum():
            messages.error(request, "Username must have 8 characters with at least one letter, number and special character")
            return redirect('signup')


        myuser = User.objects.create_user(username, email, pass1)
        myuser.last_name = lname
        myuser.first_name = fname
        myuser.isactive = False

        myuser.save()
        messages.success(request, "You have successfully made your account! A confirmation email has been sent to you! Please confirm your email to get your account activated!")

        """ subject = "Welcome to NewzXApp Login Page."
        message = "Hello "+myuser.first_name+",\nWelcome to NewzX!\nWe have also sent you a confirmation email!\nPlease confirm you email address in order to have your account activated!"
        from_email = settings.EMAIL_HOST_USER
        to_list = [myuser.email]
        send_mail(subject, message, from_email, to_list, fail_silently=True)
        
        current_site = get_current_site(request)
        email_subject = "Confirm your email @NewzX - Gmail Login!"
        message2 = render_to_string('email_confirmation.html', {
            'name':myuser.first_name,
            'domain':current_site.domain,
            'uid':urlsafe_base64_encode(force_bytes(myuser.pk)),
            'token': tokengenerated.make_token(myuser),

        })
        email = EmailMessage(
            email_subject,
            message2,
            settings.EMAIL_HOST_USER,
            [myuser.email],
        )
        email.fail_silently = True
        email.send()
        return redirect('login') """

    return render(request, "permission/signup.html")


def signing(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        pass1 = request.POST.get('pass1')

        user = authenticate(username=username, password=pass1)

        if user is not None:
            user.is_active = True
            user.save()
            login(request, user)
            fname = user.first_name
            return render(request, "permission/userPage.html")
        else:
            messages.error(request, "Invalid Credentials")
    return render(request, "permission/login.html")

def signout(request):
    logout(request)
    messages.success(request, "Logged out successfully")
    return render(request, 'permission/login.html')


def userPage(request):
    newsApi = NewsApiClient(api_key='d243031006f14b0482de8c201f7c29c4')
    top_headlines_general = newsApi.get_top_headlines(category='general')
    articles = top_headlines_general['articles']
    descr = []
    news = []
    img = []

    for k in range(len(articles)):
        a = articles[k]
        descr.append(a['description'])
        news.append(a['title'])
        img.append(a['urlToImage'])

    nlist = zip(news, descr, img)
    return render(request, "permission/userPage.html", context={"nlist": nlist})


def contact(request):
    return render(request, "permission/contact.html")


def about(request):
    return render(request, "permission/about.html")


def resetPassword(request):
    if request.method == 'POST':
        current = request.POST["currpass"]
        new_pass = request.POST["newpass"]

        user = User.objects.get(id = request.user.id)
        check_password = user.check_password(current)

        if check_password == True:
            user.set_password(new_pass)
            user.save()
            messages.success(request, "Your password has been successfully changed!!")

        else:
            messages.error(request, "Sorry, your current password is invalid. Please try again!")

    return render(request, "permission/resetPassword.html")

def profile(request):
    if request.method == 'POST':
        keywords = ["*"]
        newsApi = NewsApiClient(api_key='d243031006f14b0482de8c201f7c29c4')

        url = ('https://newsapi.org/v2/top-headlines?q=' + ','.join(keywords)) + '&language=en' + '&apiKey=' + newsApi + '&pageSize=100'

        response = request.GET(url)

        for article in response.json()['articles']:
            print(article['title'])

        print(url)

        print(response.json()['totalResults'])
        return redirect(request, 'db.sqlite3')

        currentemail = request.POST["currEmail"]
        new_email = request.POST["newEmail"]

        user = User.objects.get(id = request.user.id)
        validate_email = user.validate_email(currentemail)

        if validate_email == True:
            user.set_password(new_email)
            user.save()
            messages.success(request, "Your email has been successfully changed!!")

        else:
            messages.error(request, "Sorry, your current email is invalid. Please try again!")
    
    keyVars = request.POST.getlist('checks[]')
    if keyVars == True:
        business = request.POST["checks[]"]
        entertainment = request.POST["checks[]"]
        general = request.POST["checks[]"]
        health = request.POST["checks[]"]
        science = request.POST["checks[]"]
        sports = request.POST["checks[]"]
        technology = request.POST["checks[]"]

        newsApi = NewsApiClient(api_key='d243031006f14b0482de8c201f7c29c4')

        url = ('https://newsapi.org/v2/top-headlines?q=' + ','.join(keyVars)) + '&language=en' + '&apiKey=' + newsApi + '&pageSize=100'

        response = request.GET(url)

        for article in response.json()['articles']:
            print(article['title'])

        print(url)

        print(response.json()['totalResults'])
        return redirect(request, 'db.sqlite3')
    
    return render(request, "permission/Profile.html")


def activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        myuser = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, myuser.DoesNotExist):
        myuser = None
    
    if myuser is not None and tokengenerated.check_token(myuser, token):
        myuser.is_active = True
        myuser.save()
        login(request, myuser)
        return redirect('login')
    else:
        return render(request, 'activation_failed.html')

from django.db import models
from django.contrib.auth.models import AbstractUser, UserManager as AbstractUserManager, ConfigFiles
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db.models.signals import *
from django.db.models import F





def file_upload_count(sender, instance, created, *args, **kwargs):
    if created:
        UserProfile.objects.filter(user = instance).update(filesuploaded = F('filesuploaded')+1)

  post_save.connect(file_upload_count, sender=ConfigFiles)

class Members(models.Model):
    fname = models.CharField(max_length=200)
    lname = models.CharField(max_length=200)
    email = models.EmailField(max_length=200)
    password = models.CharField(max_length=200)

    def __str__(self):
        return self.fname + ' ' + self.lname
class UserManager(AbstractUserManager):
  pass

class User(AbstractUser):
    objects = UserManager()
class ConfigFiles(models.Model):
    user = models.ForeignKey(
    settings.AUTH_USER_MODEL, blank=True, null=True)

    Printer = models.CharField(_('Printer Model'),
    max_length=100, blank=True, null=True, unique=False, help_text="Something like 'i3'")
    printerbrand = models.CharField(_('Printer Brand'),
    max_length=100, blank=True, null=True, unique=False, help_text="Something like 'Prusa'")
    Plastic = models.CharField(_('Plastic'),    
    max_length=40, blank=True, null=True, unique=False, help_text="Something like 'ABS' or 'Nylon'")

    HDConfig = models.FileField(_('High Detail, Slow Speed'), 
    upload_to=UploadedConfigPath, validators=[validate_file_extension], help_text="Displayed as HD on Infinity-Box")
    LDConfig = models.FileField(_('Fast speed, Low Detail'), 
    upload_to=UploadedConfigLDPath, validators=[validate_file_extension], help_text="Displayed as FAST on Infinity-Box")

    pub_date = models.DateTimeField(_('date_joined'), 
    default=timezone.now)
class UserProfile(models.Model):
    user = models.OneToOneField(DemoUser, primary_key=True, verbose_name='user', related_name='profile')

    avatar_url = models.CharField(max_length=256, blank=True, null=True)

    configuploaded = models.IntegerField(_('Number of uploaded Config files'), default=0, unique=False)
    filesuploaded = models.IntegerField(_('Number of uploaded STL files'), default=0, unique=False)


    dob=models.DateField(verbose_name="dob", blank=True, null=True)

    def __str__(self):
        return force_text(self.user.email)

    class Meta():
        db_table = 'user_profile'
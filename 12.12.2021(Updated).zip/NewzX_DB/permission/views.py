from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages, admin
from django.contrib.auth import authenticate, login, logout
from linking import settings
from django.core.mail import send_mail
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_text
from . tokens import tokengenerated
from django.core.mail import EmailMessage, send_mail
from rest_framework import status
from rest_framework import generics
from rest_framework.response import Response
from django.contrib.auth.models import User
from .serializers import ChangePasswordSerializer
from rest_framework.permissions import IsAuthenticated   
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from .forms import UpdateUserForm, UpdateProfileForm


@login_required
def Profile(request):
    if request.method == 'POST':
        user_form = UpdateUserForm(request.POST, instance=request.user)
        profile_form = UpdateProfileForm(request.POST, request.FILES, instance=request.user.profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Your profile is updated successfully')
            return redirect(to='permission-Profile')
    else:
        user_form = UpdateUserForm(instance=request.user)
        profile_form = UpdateProfileForm(instance=request.user.profile)

    return render(request, 'permission/Profile.html', {'user_form': user_form, 'profile_form': profile_form})

class ChangePasswordView(generics.UpdateAPIView):
    """
    An endpoint for changing password.
    """
    serializer_class = ChangePasswordSerializer
    model = User
    permission_classes = (IsAuthenticated,)

    def get_object(self, queryset=None):
        obj = self.request.user
        return obj

    def update(self, request, *args, **kwargs):
        self.object = self.get_object()
        serializer = self.get_serializer(data=request.data)

        if serializer.is_valid():
            # Check old password
            if not self.object.check_password(serializer.data.get("current_password")):
                return Response({"current_password": ["Wrong password."]}, status=status.HTTP_400_BAD_REQUEST)
            # set_password also hashes the password that the user will get
            self.object.set_password(serializer.data.get("new_password"))
            self.object.save()
            response = {
                'status': 'success',
                'code': status.HTTP_200_OK,
                'message': 'Password updated successfully',
                'data': []
            }

            return Response(response)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# Create your views here.
def index(request):
    return render(request, "permission/index.html")


def signup(request):
    if request.method=="POST":
        lname = request.POST.get('lname')
        fname = request.POST.get('fname')
        username = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('pass1')
        pass2 = request.POST.get('pass2')
        if User.objects.filter(username=username):
            messages.error(request, "Username already exists! Please try another username!")
            return redirect('index')
        if User.objects.filter(email=email):
            messages.error(request, "Email is already in use!")
            return redirect('index')
        if len(username)<8:
            messages.error(request, "Username must be 8 characters minimum")
            return redirect('index')
        if pass1 != pass2:
            messages.error(request, "Passwords do not match!")
            return redirect('index')

        if not username.isalnum():
            messages.error(request, "Username must have 8 characters with at least one letter, number and special character")
            return redirect('index')


        myuser = User.objects.create_user(username, email, pass1)
        myuser.last_name = lname
        myuser.first_name = fname
        myuser.isactive = False

        myuser.save()
        messages.success(request, "You have successfully made your account! A confirmation email has been sent to you! Please confirm your email to get your account activated!")
        
        subject = "Welcome to NewzXApp Login Page."
        message = "Hello "+myuser.first_name+",\nWelcome to NewzX!\nWe have also sent you a confirmation email!\nPlease confirm you email address in order to have your account activated!"
        from_email = settings.EMAIL_HOST_USER
        to_list = [myuser.email]
        send_mail(subject, message, from_email, to_list, fail_silently=True)
        
        current_site = get_current_site(request)
        email_subject = "Confirm your email @NewzX - Gmail Login!"
        message2 = render_to_string('email_confirmation.html', {
            'name':myuser.first_name,
            'domain':current_site.domain,
            'uid':urlsafe_base64_encode(force_bytes(myuser.pk)),
            'token': tokengenerated.make_token(myuser),

        })
        email = EmailMessage(
            email_subject,
            message2,
            settings.EMAIL_HOST_USER,
            [myuser.email],
        )
        email.fail_silently = True
        email.send()
        return redirect('login')

    return render(request, "permission/signup.html")


def signing(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        pass1 = request.POST.get('pass1')

        user = authenticate(username=username, password=pass1)

        if user is not None:
            user.is_active = True
            user.save()
            login(request, user)
            fname = user.first_name
            return render(request, "permission/userPage.html", {'fname': fname})
        else:
            messages.error(request, "Invalid Credentials")
    return render(request, "permission/login.html")

def signout(request):
    logout(request)
    messages.success(request, "Logged out successfully")
    return redirect('login')


def userPage(request):
    return render(request, "permission/userPage.html")

def contact(request):
    return render(request, "permission/contact.html")

def about(request):
    return render(request, "permission/about.html")
def F_PasswordDone(request):
    if request.method == 'POST':
        return redirect('login')
    return render(request, "permission/F_PasswordDone.html")   

def news(request):
    return render(request, "permission/news.html")

def activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        myuser = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, myuser.DoesNotExist):
        myuser = None
    
    if myuser is not None and tokengenerated.check_token(myuser, token):
        myuser.is_active = True
        myuser.save()
        login(request, myuser)
        return redirect('index')
    else:
        return render(request, 'activation_failed.html')